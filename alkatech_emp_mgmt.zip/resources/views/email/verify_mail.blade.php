<h1>Welcome to Alkatech</h1><br>
<a href="{{url('/email_verification')}}/{{$rand_id}}"> verify</a> your email.