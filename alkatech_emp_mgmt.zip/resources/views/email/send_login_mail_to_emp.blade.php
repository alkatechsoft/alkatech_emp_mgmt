<h1>Welcome to Alkatech</h1>
lOGIN DETAILS:<br>
EMAIL: {{$email}}<br>
PASSWORD: {{$password}}<br>
NOTE: We have send verification link to {{$email}} please login and verify email, then login to your account