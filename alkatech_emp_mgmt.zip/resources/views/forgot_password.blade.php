<h1>Change Your Password</h1>
<a href="{{url('/forgot_password_process_change')}}/{{$rand_id}}"> Click here</a>