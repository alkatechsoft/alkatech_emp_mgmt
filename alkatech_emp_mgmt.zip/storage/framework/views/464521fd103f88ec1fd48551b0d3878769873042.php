<h1>Welcome to Alkatech</h1>
lOGIN DETAILS:<br>
EMAIL: <?php echo e($email); ?><br>
PASSWORD: <?php echo e($password); ?><br>
NOTE: We have send verification link to <?php echo e($email); ?> please login and verify email, then login to your account<?php /**PATH C:\dev-work\my-git\alkatech_emp_mgmt\resources\views/email/send_login_mail_to_emp.blade.php ENDPATH**/ ?>