
<?php $__env->startSection('page_title','Admin | Dashboard'); ?>
<?php $__env->startSection('attendance_selected','active'); ?>

<?php $__env->startSection('container'); ?>
 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Admin</a></li>
              <li class="breadcrumb-item active">Attendance Management</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
 
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title"><b>UPLOAD ATTENDANCE</b></h3>
              </div>
              <!-- /.card-header -->
              <form id="upload_attendance_form">
                <?php echo csrf_field(); ?>

              <div class="card-body">
                <div class="form-group">
                  <label>SELECT EMPLOYEE</label>
                  <select required name="emp_id" id="emp_search"  class="form-control select2" style="width: 100%;">slect
                    <option id="search_value" value="">Search employee</option>
                  </select>
                </div>
              <div id="wrap" class="card-body">
                <div class="row" id="TextBoxContainer">
                  <div class="col-4">
                    <input type="date" id="__from_date" value="" name="date[]" onchange="attendance_filter_before_upload_handler();" class="form-control" required  placeholder="">
                  </div>
                  <div class="col-4">
                    <input type="time" id="__in_time" value="" name="in_time[]"  class="form-control" required placeholder="">
                  </div>
                  <div class="col-4">
                    <input type="time" id="__out_time" value="" name="out_time[]"  class="form-control" required placeholder="">
                  </div>
                </div>
	            <input type="hidden" id="box_count" value="1">
	            <input type="hidden" name="__update_id" id="__update_id" value="">
 
              </div>
              <div class="row">

              <div class="btn-group mr-2 col" role="group" aria-label="First group">
                <a onclick="add_more()" class="btn btn-primary "><i class="fa fa-plus"></i></a>
                <button type="submit" class="btn btn-success upload_update"><i class="fa fa-upload"></i>&nbsp;&nbsp;UPLOAD</button>
              </div>
            </div>

            


              </form>
              <!-- /.card-body -->
             
           
            </div>
              <!-- /.card-body -->
            </div>
            
            <!-- /.card -->
 
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
 
  

<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev-work\my-git\alkatech_emp_mgmt\resources\views/admin/upload_attendance.blade.php ENDPATH**/ ?>